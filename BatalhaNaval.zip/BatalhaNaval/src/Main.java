import java.io.FileNotFoundException;
import java.io.IOException;

import com.itextpdf.text.DocumentException;

import Relatorio.GeradorDeRelatorio;
import Tela.TelaLogin;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, DocumentException {

		TelaLogin telaLogin = new TelaLogin();
		
	
		
	}

}
